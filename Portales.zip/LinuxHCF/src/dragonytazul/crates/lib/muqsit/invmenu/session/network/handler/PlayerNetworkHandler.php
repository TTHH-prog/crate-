<?php

declare(strict_types=1);

namespace dragonytazul\crates\lib\muqsit\invmenu\session\network\handler;

use Closure;
use dragonytazul\crates\lib\muqsit\invmenu\session\network\NetworkStackLatencyEntry;

interface PlayerNetworkHandler{

	public function createNetworkStackLatencyEntry(Closure $then) : NetworkStackLatencyEntry;
}