<?php

declare(strict_types=1);

namespace dragonytazul\crates\lib\muqsit\invmenu\type;

use dragonytazul\crates\lib\muqsit\invmenu\InvMenu;
use dragonytazul\crates\lib\muqsit\invmenu\type\graphic\InvMenuGraphic;
use pocketmine\inventory\Inventory;
use pocketmine\player\Player;

interface InvMenuType{

	public function createGraphic(InvMenu $menu, Player $player) : ?InvMenuGraphic;

	public function createInventory() : Inventory;
}