<?php

namespace dragonytazul\crates;

use dragonytazul\crates\crate\Crate;
use dragonytazul\crates\lib\FloatingTextApi;
use pocketmine\world\particle\BlockBreakParticle;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\VanillaItems;
use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\world\Position;
use pocketmine\utils\TextFormat;

class EventHandler implements Listener
{
    
    public int $count = 0;
    
    public function handlerItemUse(PlayerItemUseEvent $ev): void {
        $player = $ev->getPlayer();
        $itemInHand = $player->getInventory()->getItemInHand();
        
        foreach(Main::getPlacedCrates() as $pos => $crate) {
                if ($itemInHand->getNamedTag()->getTag("crate") !== null && $itemInHand->getNamedTag()->getString("crate") === $crate->getName()) {
                    $crate->giveRewardsChance($player);
                    //$player->getInventory()->setItemInHand($itemInHand->getCount() > 1 ? $itemInHand->setCount($itemInHand->getCount() - 1) : VanillaItems::AIR());
                    //$player->sendMessage(TextFormat::GREEN . "You have opened a " . $crate->getDisplayName() . TextFormat::GREEN . " crate.");
                    $ev->cancel();
                }
        }
    }

    public function handlerQuit(PlayerQuitEvent $ev): void
    {
        $player = $ev->getPlayer();
        if (Main::getCratePlacing($player) != null || Main::isRemovingCrate($player)) {
            Main::removeFromPlace($player);
            Main::removeFromRemoving($player);
        }
    }

    public function handlerBreak(BlockBreakEvent $ev): void
    {
        $player = $ev->getPlayer();
        $position = $ev->getBlock()->getPosition();

        if (Main::getCratePlacing($player) != null || Main::checkCrate($position) != null) {
            $ev->cancel();
        }
    }

    /**
     * @param PlayerInteractEvent $ev
     *
     * @priority HIGHEST
     * @handleCancelled true
     */
    public function handlerInteract(PlayerInteractEvent $ev): void
    {
        $player = $ev->getPlayer();
        $itemInHand = $player->getInventory()->getItemInHand();
        $block = $ev->getBlock();
        $position = $block->getPosition();
        $crate = Main::checkCrate($position);
        
        if ($itemInHand->getNamedTag()->getTag("crate") !== null) $ev->cancel();
        
        if ($crate === null) {
            if (Main::isRemovingCrate($player)) {
                $player->sendMessage(TextFormat::RED . "Is not allowed to remove a crate.");
                $ev->cancel();
                return;
            }
            $placingCrate = Main::getCratePlacing($player);
            if ($placingCrate !== null) {
                Main::placeCrate($position, $placingCrate);
                Main::removeFromPlace($player);
                $placingCrate->setPlace(true);
                $player->sendMessage(TextFormat::GREEN . "You have placed a " . $placingCrate->getDisplayName() . TextFormat::GREEN . " crate.");
                $ev->cancel();
                return;
            }
            return;
        }

        if (Main::isRemovingCrate($player)) {
            Main::removePlaceCrate($position);
            Main::removeFromRemoving($player);
            $ev->cancel();
            return;
        }

        if ($ev->getAction() == PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            if ($itemInHand->getNamedTag()->getTag("crate") === null || $itemInHand->getNamedTag()->getString("crate") !== $crate->getName()) {
                $player->sendMessage(TextFormat::RED . "You do not have a " . $crate->getDisplayName() . TextFormat::RED . " key.");
                $ev->cancel();
                return;
            }
            $crate->giveRewardsChance($player);
            //$itemInHand->pop();
            //$player->getInventory()->setItemInHand($itemInHand);
            //$player->sendMessage(TextFormat::GREEN . "You have opened a " . $crate->getDisplayName() . TextFormat::GREEN . " crate.");
            $glass = VanillaBlocks::STAINED_GLASS_PANE();
            $fillItems = [$glass->setColor(DyeColor::BLACK()), $glass->setColor(DyeColor::CYAN()), $glass->setColor(DyeColor::MAGENTA()), $glass->setColor(DyeColor::RED()), $glass->setColor(DyeColor::WHITE()), $glass->setColor(DyeColor::PINK())];
            $player->getWorld()->addParticle($block->getPosition()->add(0.5, 1, 0.5), new BlockBreakParticle($fillItems[array_rand($fillItems)]), [$player]);
            $ev->cancel();
        } else if ($ev->getAction() == PlayerInteractEvent::LEFT_CLICK_BLOCK) {
            $player->getWorld()->addParticle($block->getPosition()->add(0.5, 0.5, 0.5), new BlockBreakParticle($block), [$player]);
            $crate->open($player);
            $ev->cancel();
        }
    }

    public function handlerDamage(EntityDamageEvent $ev): void
    {
        if ($ev->getEntity() instanceof Hologram) {
            $ev->cancel();
        }
    }

    private array $playersViewing = [];
    private array $lineCount = [];
    
    /*public function onMove(PlayerMoveEvent $event): void
    {
        $player = $event->getPlayer();
        $radius = 8;

        if ($event->getFrom()->getX() === $event->getTo()->getX() && $event->getFrom()->getZ() === $event->getTo()->getZ()) {
            return;
        }

        foreach (Main::getPlacedCrates() as $stringPos => $crate) {
            $cratePosition = Util::fromString($stringPos);
            $distance = $player->getPosition()->distance($cratePosition);
            
            if ($cratePosition->world->getId() !== $player->getWorld()->getId()) return;

            $playerName = $player->getName();
            if ($distance > $radius) {
                if (isset($this->playersViewing[$playerName][$crate->getName()])) {
                    foreach($this->playersViewing[$playerName][$crate->getName()] as $hol) {
                        $hol->removeFrom($player);
                        unset($this->playersViewing[$playerName][$crate->getName()][$hol->getEntityID()]);
                        unset($this->playersViewing[$playerName][$crate->getName()]);
                        foreach($this->lineCount[$playerName][$crate->getName()] as $line) {
                            unset($this->playersViewing[$playerName][$crate->getName()][$line]);
                            unset($this->playersViewing[$playerName][$crate->getName()]);
                            //$this->count = 0;
                        }
                        //var_dump('Se oculto el texto ' . $hol->getEntityID() . ' a ' . $playerName);
                    }
                }
            } else {
                if (!isset($this->playersViewing[$playerName][$crate->getName()])) {
                    $lines = $crate->getHologram();
                    $newY = $cratePosition->y + 0.28;
                    $LINES = array_reverse($lines);
                    
                    foreach ($LINES as $LINE) {
                        if (isset($this->lineCount[$playerName][$crate->getName()]) && isset($this->playersViewing[$playerName][$crate->getName()])) {
                            if ((count($LINES) === count($this->lineCount[$playerName][$crate->getName()])) && (count($LINES) === count($this->playersViewing[$playerName][$crate->getName()]))) {
                                //var_dump('No se puede mostrar mas Texto');
                                return;
                            }
                        }
                        
                        $newY += 0.28;
                        $hol = new Hologram();
                        $hol->showTo($player, Util::fromString("{$cratePosition->x}:{$newY}:{$cratePosition->z}:{$cratePosition->world->getFolderName()}"), $LINE);
                        $this->playersViewing[$playerName][$crate->getName()][$hol->getEntityID()] = $hol;
                        //var_dump('Se mostro el texto ' . $hol->getEntityID() . ' a ' . $playerName);
                        $this->count++;
                        $this->lineCount[$playerName][$crate->getName()][$hol->getEntityID()] = $this->count;
                        $this->count = 0;
                    }
                    //$hol = new Hologram();
                    //$hol->showTo($player, $cratePosition, implode("\n", $crate->getHologram()));
                    //$this->playersViewing[$playerName][$crate->getName()] = $hol;
                    # var_dump('Se mostro el texto ' . $hol->getEntityID() . ' a ' . $playerName);
                }
            }
        }
    }*/
}