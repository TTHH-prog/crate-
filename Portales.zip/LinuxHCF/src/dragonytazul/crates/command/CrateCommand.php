<?php

namespace dragonytazul\crates\command;

use dragonytazul\crates\crate\Crate;
use dragonytazul\crates\effect\CrateEffect;
use dragonytazul\crates\lib\muqsit\invmenu\InvMenu;
use dragonytazul\crates\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

class CrateCommand extends Command
{

    public function __construct()
    {
        parent::__construct("crate", "Manage your server crates", "Usage: /crate <create|place|list|help|delete|remove|set_chance>");
        $this->setPermission("crate.use.command");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$this->testPermission($sender)) {
            $sender->sendMessage(TextFormat::RED . "You do not have permission to use this command.");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(TextFormat::RED . "Only players can use this command.");
            return;
        }

        if (count($args) < 1) {
            $sender->sendMessage(TextFormat::RED . $this->usageMessage);
            return;
        }
        switch ($args[0]) {
            case 'set_chance':
                if (count($args) < 2) {
                    $sender->sendMessage(TextFormat::RED . "Usage: /crate set_chance <chance>");
                    return;
                }
                $chance = $args[1];
                if (!is_numeric($chance)) {
                    $sender->sendMessage(TextFormat::RED . "Chance must be a number.");
                    return;
                }
                if ($chance > 100 || $chance < 0) {
                    $sender->sendMessage(TextFormat::RED . "Chance must be between 0 and 100.");
                    return;
                }
                $itemInHand = $sender->getInventory()->getItemInHand();
                $itemInHand->getNamedTag()->setInt("chance", (int)$chance);
                $sender->getInventory()->setItemInHand($itemInHand);
                $sender->sendMessage(TextFormat::GREEN . "Chance set to " .  (int)$chance . "% for " . $itemInHand->getName());
                break;
            case "create":
                if (count($args) < 5) {
                    $sender->sendMessage(TextFormat::RED . "Usage: /crate create <name> <color> <reward_amount> <1=hopper | 2=chest | 3=double_chest | ?default=hopper>");
                    return;
                }
                $name = $args[1];
                $color = TextFormat::colorize($args[2]);
                $rewardAmount = $args[3];

                if (Main::getCrate($name) !== null) {
                    $sender->sendMessage(TextFormat::RED . "Crate " . $name . " already exists.");
                    return;
                }

                if (!is_numeric($rewardAmount)) {                    $sender->sendMessage(TextFormat::RED . "Reward amount must be a number.");
                    return;
                }

                if (!isset($args[4])) {
                    $args[4] = 1;
                }
                switch ($args[4]) {
                        case '1':
                          $menu = "invmenu:hopper";
                        break;
                        case '2':
                          $menu = "invmenu:chest";
                        break;
                        case '3':
                          $menu =  "invmenu:double_chest";
                        break;
                }
                $crate = new Crate($name, $color, $menu);
                $crate->setRewardAmount($rewardAmount);
                $crate->setMenu($menu);
                $this->openEditContentCrate($sender, $crate);
                break;
            case 'delete':
                if (count($args) < 2) {
                    $sender->sendMessage(TextFormat::RED . "Usage: /crate delete <name>");
                    return;
                }
                $name = $args[1];
                $crate = Main::getCrate($name);
                if ($crate === null) {
                    $sender->sendMessage(TextFormat::RED . "Crate " . $name . " does not exist.");
                    return;
                }
                Main::deleteCrate($crate);
                break;
            case 'remove':
                Main::setRemovingCrate($sender);
                break;
            case "place":
                if (count($args) < 2) {
                    $sender->sendMessage(TextFormat::RED . "Usage: /crate place <name>");
                    return;
                }
                $name = $args[1];

                $crate = Main::getCrate($name);
                if ($crate === null) {
                    $sender->sendMessage(TextFormat::RED . "Crate " . $name . " does not exist.");
                    return;
                }
                Main::addToPlace($sender, $crate);
                break;
            case 'list':
                if (count(Main::getCrates()) < 1) {
                    $sender->sendMessage(TextFormat::RED . "No crates found.");
                    return;
                }
                $sender->sendMessage(TextFormat::colorize(TextFormat::DARK_GRAY . "------------------------------"));
                $sender->sendMessage(TextFormat::colorize(TextFormat::GREEN . "Crate List"));
                $i = 1;
                foreach (Main::getCrates() as $crate) {
                    $sender->sendMessage(TextFormat::MINECOIN_GOLD . $i . ". " . $crate->getDisplayName());
                    $sender->sendMessage("  " . TextFormat::YELLOW . "Color: " . TextFormat::WHITE . $crate->getColor());
                    $sender->sendMessage("  " . TextFormat::YELLOW . "Key Item: " . TextFormat::WHITE . $crate->getItemKey()->getName());
                    $sender->sendMessage("  " . TextFormat::YELLOW . "Reward Amount: " . TextFormat::WHITE . $crate->getRewardAmount());
                    $i++;
                }
                $sender->sendMessage(TextFormat::colorize(TextFormat::DARK_GRAY . "------------------------------"));
                break;
            case 'help':
                $sender->sendMessage(TextFormat::colorize(TextFormat::DARK_GRAY . "------------------------------"));
                $sender->sendMessage(TextFormat::colorize(TextFormat::GREEN . "Crate Help"));
                $sender->sendMessage(TextFormat::YELLOW . "  /crate create - " . TextFormat::WHITE . "Use this command to create a new crate.");
                $sender->sendMessage(TextFormat::YELLOW . "  /crate place - " . TextFormat::WHITE . "Use this command to place a crate on a block.");
                $sender->sendMessage(TextFormat::YELLOW . "  /crate list - " . TextFormat::WHITE . "Use this command to list all crates.");
                $sender->sendMessage(TextFormat::YELLOW . "  /crate edit - " . TextFormat::WHITE . "Use this command to edit a crate.");
                $sender->sendMessage(TextFormat::YELLOW . "  /crate delete - " . TextFormat::WHITE . "Use this command to delete a crate.");
                $sender->sendMessage(TextFormat::YELLOW . "  /crate remove - " . TextFormat::WHITE . "Use this command to remove a placed crate.");
                $sender->sendMessage(TextFormat::YELLOW . "  /key giveall - " . TextFormat::WHITE . "Use this command to give a crate key to all online players.");
                $sender->sendMessage(TextFormat::YELLOW . "  /key give - " . TextFormat::WHITE . "Use this command to give a crate key to a specific player.");
                $sender->sendMessage(TextFormat::colorize(TextFormat::DARK_GRAY . "------------------------------"));

                break;
            case 'edit':
                if (count($args) < 2) {
                    $sender->sendMessage(TextFormat::RED . "Usage: /crate edit <content|rewards_amount|key_item|hologram|effect|color> <crate_name>");
                    return;
                }
                switch ($args[1]) {
                    case "content":
                        if (count($args) < 3) {
                            $sender->sendMessage(TextFormat::RED . "Usage: /crate edit content <crate_name>");
                            return;
                        }
                        $name = $args[2];
                        $crate = Main::getCrate($name);
                        if ($crate === null) {
                            $sender->sendMessage(TextFormat::RED . "Crate " . $name . " does not exist.");
                            return;
                        }
                        $this->openEditContentCrate($sender, $crate);
                        break;
                    case "rewards_amount":
                        if (count($args) < 4) {
                            $sender->sendMessage(TextFormat::RED . "Usage: /crate edit rewards_amount <crate_name> <amount>");
                            return;
                        }
                        $name = $args[2];
                        $amount = $args[3];
                        $crate = Main::getCrate($name);
                        if ($crate === null) {
                            $sender->sendMessage(TextFormat::RED . "Crate " . $name . " does not exist.");
                            return;
                        }
                        if (!is_numeric($amount)) {
                            $sender->sendMessage(TextFormat::RED . "Reward amount must be a number.");
                            return;
                        }
                        $crate->setRewardAmount($amount);
                        $sender->sendMessage(TextFormat::GREEN . "Crate " . $name . " rewards amount updated.");
                        break;
                    case "key_item":
                        if (count($args) < 3) {
                            $sender->sendMessage(TextFormat::RED . "Usage: /crate edit key_item <crate_name>");
                            return;
                        }
                        $name = $args[2];
                        $crate = Main::getCrate($name);

                        $item = $sender->getInventory()->getItemInHand();

                        if ($item->getTypeId() === 0) {
                            $sender->sendMessage(TextFormat::RED . "You must have an item in your hand.");
                            return;
                        }

                        if ($crate === null) {
                            $sender->sendMessage(TextFormat::RED . "Crate " . $name . " does not exist.");
                            return;
                        }

                        $crate->setItemKey($item);
                        $sender->sendMessage(TextFormat::GREEN . "Crate " . $name . " key item updated.");
                        break;
                    case "hologram":
                        if (count($args) < 4) {
                            $sender->sendMessage(TextFormat::RED . "Usage: /crate edit hologram <crate_name> <hologram>");
                            return;
                        }
                        $name = $args[2];
                        $hologram = explode(":", TextFormat::colorize($args[3]));
                        $crate = Main::getCrate($name);
                        if ($crate === null) {
                            $sender->sendMessage(TextFormat::RED . "Crate " . $name . " does not exist.");
                            return;
                        }
                        $crate->setHologram($hologram);
                        $sender->sendMessage(TextFormat::GREEN . "Crate " . $name . " hologram updated.");
                        Main::updateHolograms();
                        break;
                    case "effect":
                        if (count($args) < 4) {
                            $sender->sendMessage(TextFormat::RED . "Usage: /crate edit effect <crate_name> <effect>");
                            return;
                        }
                        $name = $args[2];
                        $effect = $args[3];
                        $crate = Main::getCrate($name);
                        if ($crate === null) {
                            $sender->sendMessage(TextFormat::RED . "Crate " . $name . " does not exist.");
                            return;
                        }
                        if (!CrateEffect::isEffect($effect)) {
                            $sender->sendMessage(TextFormat::RED . "Invalid effect. Valid effects: " . implode(", ", CrateEffect::getEffects()));
                            return;
                        }
                        $crate->setEffect($effect);
                        $sender->sendMessage(TextFormat::GREEN . "Crate " . $name . " effect updated.");
                        break;
                    case 'color':
                        if (count($args) < 4) {
                            $sender->sendMessage(TextFormat::RED . "Usage: /crate edit color <crate_name> <color>");
                            return;
                        }
                        $name = $args[2];
                        $color = $args[3];
                        $crate = Main::getCrate($name);
                        if ($crate === null) {
                            $sender->sendMessage(TextFormat::RED . "Crate " . $name . " does not exist.");
                            return;
                        }
                        $crate->setColor($color);
                        $sender->sendMessage(TextFormat::GREEN . "Crate " . $name . " color updated.");
                        break;
                }

                break;
            default:
                $sender->sendMessage(TextFormat::RED . $this->usageMessage);
                break;
        }
    }

    public function openEditContentCrate(Player $player, Crate $crate) : void
    {
        $menu = InvMenu::create($crate->getMenu());
        $menu->setName(TextFormat::YELLOW . "Create " .$crate->getName() . " content.");

        foreach ($crate->getRewards() as $slot => $reward) {
            $menu->getInventory()->setItem($slot, $reward);
        }
        
        foreach ($crate->getDecorative() as $slot => $reward) {
            $menu->getInventory()->setItem($slot, $reward);
        }

        $menu->setInventoryCloseListener(function () use ($player, $crate, $menu) {
            $newMenu = InvMenu::create($crate->getMenu());
            $decorativeMenu = InvMenu::create($crate->getMenu());
            foreach($menu->getInventory()->getContents() as $slot => $item) {
                if (!$item->getNamedTag()->getTag("type")) {
                    $newMenu->getInventory()->setItem($slot, $item);
                } else {
                    $decorativeMenu->getInventory()->setItem($slot, $item);
                }
            }
            $crate->setRewards($newMenu->getInventory()->getContents());
            $crate->setDecorative($decorativeMenu->getInventory()->getContents());
            $player->sendMessage(TextFormat::GREEN . "Crate " . $crate->getName() . " content updated.");
            Main::createCrate($crate);
        });

        $menu->send($player);
    }
}